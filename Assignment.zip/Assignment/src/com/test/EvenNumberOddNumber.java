package com.test;

import java.util.Scanner;

public class EvenNumberOddNumber {
	public static void main(String[] args) {
		System.out.println("Enter the Number!!");
		Scanner scanner = new Scanner(System.in);
		int num=scanner.nextInt();
		for(int i=0;i<=num;i++) {
			
		}
		if(num%2==0) {
			System.out.println(num+":"+" is an even number");
		}else {
			System.out.println(num+":"+" is an odd number");
		}
	}
}
