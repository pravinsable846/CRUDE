package com.test;

import java.util.Scanner;

public class FactorialNumber {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number to find its factorial: ");
        int num = sc.nextInt();
        int result = factorial(num);
        System.out.println("The factorial of " + num + " is " + result);
    }

    static int factorial(int n) {
        if (n == 0) return 1;
        return n * factorial(n - 1);
    }
}
